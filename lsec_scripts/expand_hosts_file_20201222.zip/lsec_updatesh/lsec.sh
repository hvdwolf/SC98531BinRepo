#!/system/bin/sh 
# 

mount -o remount,rw /system
cp /storage/sdcard1/lsec_updatesh/hosts /system/etc/hosts

