#!/system/bin/sh 
#
# Make a "raw" backup of the recovery and boot partition

dd if=/dev/block/mmcblk0p25 of=/storage/sdcard1/boot.img
dd if=/dev/block/mmcblk0p3 of=/storage/sdcard1/recovery.img
