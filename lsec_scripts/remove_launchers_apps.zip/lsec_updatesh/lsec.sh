#!/system/bin/sh 
#

# necessary or not, we simply remount the partitions read-write
mount -o remount,rw /system
mount -o remount,rw /oem

# Remove unnecessary launchers and apps
rm -rf /oem/app/190043001_com.android.launcher2
rm -f /data/dalvik-cache/x86_64/oem@app@190043001_com.android.launcher2*
rm -rf /data/data/com.android.launcher2
rm -rf /data/system/package_cache/1/190043001_com.android.launcher2*

rm -rf /oem/app/190043003_com.android.launcher4
rm -f /data/dalvik-cache/x86_64/oem@app@190043003_com.android.launcher4*
rm -rf /data/data/com.android.launcher4
rm -rf /data/system/package_cache/1/190043003_com.android.launcher4*

rm -rf /oem/app/190043002_com.android.launcher5
rm -f /data/dalvik-cache/x86_64/oem@app@190043002_com.android.launcher5*
rm -rf /data/data/com.android.launcher5
rm -rf /data/system/package_cache/1/190043002_com.android.launcher5*


# FYT apps
rm -rf /oem/app/190000000_com.android.calculator2
rm -f /data/dalvik-cache/x86_64/oem@app@190000000_com.android.calculator2*
rm -rf /data/data/com.android.calculator2
rm -rf /data/system/package_cache/1/190000000_com.android.calculator2*

rm -rf /oem/app/190000000_com.syu.tv
rm -f /data/dalvik-cache/x86_64/oem@app@190000000_com.syu.tv*
rm -rf /data/data/com.syu.tv
rm -rf /data/system/package_cache/1/190000000_com.syu.tv*

# system apps
rm -rf /system/app/BasicDreams
rm -rf /data/data/com.android.dreams.basic
rm -rf /data/system/package_cache/1/BasicDreams*

rm -rf /system/app/PhotoTable
rm -rf /data/data/com.android.dreams.phototable
rm -rf /data/system/package_cache/1/PhotoTable*

rm -rf /system/app/FlipToMute
rm -rf /data/data/FlipToMute
rm -rf /data/system/package_cache/1/FlipToMute*

rm -rf /system/app/YouTube
rm -rf /data/data/YouTube
rm -rf /data/system/package_cache/1/Youtube*
