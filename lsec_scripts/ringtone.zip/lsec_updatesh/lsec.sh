#!/system/bin/sh 
# 

mount -o remount,rw /system
cp /storage/sdcard1/lsec_updatesh/blink_ring.mp3 /system/blink_ring.mp3
chmod 0644 /system/blink_ring.mp3

printf "Done!!"
printf "Wait for the system to tell you to remove the USB-stick/SD-card"
